#ifndef CACHE_SIZE
#define CACHE_SIZE 16  // how many messages in the cache
#endif

#ifndef MAX_MESSAGE_SIZE
#define MAX_MESSAGE_SIZE 1024  // how many bytes for each message in the cache
#endif

// calculate space for one page of the cache
#define NON_STRINGS_SIZE (sizeof(int) + sizeof(time_t) + 2 * sizeof(bool))
#define STRING_SIZE (MAX_MESSAGE_SIZE - NON_STRINGS_SIZE)
#define MAX_SENDER_SIZE 128
#define MAX_RECEIVER_SIZE 128
#define MAX_CONTENT_SIZE (STRING_SIZE - MAX_SENDER_SIZE - MAX_RECEIVER_SIZE)

// globals for how to save messages to the disk as a CSV string
#define MESSAGE_FILENAME_FORMAT "data/message%d.txt"  // where %d is the message id number
#define TIME_FORMAT "%Y-%m-%d %H:%M:%S"
#define TIME_FORMAT_LEN 19
#define MAX_CSV_LENGTH (TIME_FORMAT_LEN + MAX_SENDER_SIZE + MAX_RECEIVER_SIZE + MAX_CONTENT_SIZE + 21)
/*
csv format: id,sender,receiver,time_sent,delivered_flag,content
21 <-- (10 digit max id number) + (1 character delivered_flag) + (5 commas) + (5 extra chars for padding/safety)
*/

#define NEXT_ID_PATH "data/_NEXT_ID.txt"  // file that tells us the next un-used id number